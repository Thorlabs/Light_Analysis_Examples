# -*- coding: utf-8 -*-
"""
   Anyvisa is wrapper for TL Visa and NI Visa device communication via SCPI commands

   This wrapper class allows SCPI communication via USB/TMC, Serial Port or Ethernet
   devices. For USB/TMC two different drivers are supported. By default Thorlabs
   devices bring their own driver and Visa library. They are also supported by
   the National Instrument Visa driver. A single USB device only uses one of the
   two driver options at the same time. This library is a wrapper for both libraries
   and allows a stanadarized communication interface regardless of the actually
   used transport library. NI Visa is NOT distributed along with this library. So
   by default only TL Visa is used for communication. This library allows communciation
   with THorlabs USB/TMC devices. USB/TMC equipment of other vendors are not supported.
   NI Visa USB/TMC driver might be used with Thorlabs and 3 party USB/TMC equipment as well.
   For serial port there is no such instrument driver necessary. Thorlabs ethernet devices 
   are only fully supported by TLvisa. Nevertheless NI Visa can also be used for Thorlabs 
   ethernet communication. Device search and transport encryption are supported only by 
   TL Visa. 

   Thorlabs GmbH - Proprietary License! Read License.txt
"""
__copyright__ = "copyright(c) 2022-2023, Thorlabs GmbH"
__date__ = "30-Apr-2023"
__license__ = "Proprietary"
__version__ = "0.2.0"

from typing import List
import re

isNiVisa = False
isTLVisa = False

try:
    import pyvisa
    isNiVisa = True
except ImportError:
    pass 

try:
    from  .TL_VisaWrapper import TL_Visa, TL_VisaIOError, TL_VisaIOWarning
    isTLVisa = True
except ImportError:
    pass

class AnyVisaIOError(Exception):
    """Communication channel Input/Output error exception class"""
    def __init__(self, errCode, message):
        self.errCode = errCode
        message = str(errCode) + ' (' + hex(errCode & (2**32-1)) + ') - Error: ' + message
        super().__init__(message)
        
class AnyVisaIOWarning(Exception):
    """Communication channel Input/Output warning exception class"""
    def __init__(self, errCode, message):
        self.errCode = errCode
        message = str(errCode) + ' (' + hex(errCode & (2**32-1)) + ') - Warning: ' + message
        super().__init__(message)

class AnyVisaDeviceError(Exception):
    """Device reports an error exception class"""
    def __init__(self, errCode, message):
        self.errCode = errCode
        message = str(errCode) + ' (' + hex(errCode & (2**32-1)) + ') - Device reported an error: ' + message
        super().__init__(message)
        
class AnyVisaException(Exception):
    """Library internal error exception class"""
    def __init__(self, message):
        super().__init__(message)

class AnyVisaDeviceWrapper(object):
    """AnyVisa abstract device class

    This class defines a common wrapper inteface for different
    visa communication interfaces.  
    """
    def __init__(self, resStr : str, backend : str):
         """Constructs a new abstract AnyVisa device

         Parameters:
            resStr (str): Device name resource string like USB::0x1234::125::A22-5::INSTR
            backend (str): Name of the used transport layer backend
         """
         self.resourceStr = resStr
         self.backend = backend
    
    def __enter__(self):
        """Opens device for with statement"""
        self.open()
        return self
        
    def __exit__(self, type, value, traceback):
        """Closes device and releases library for with statement

            Parameters:
                type        type of exception object
                value       exception object
                traceback   exception traceback object
        """
        try:
            self.close()
        except Exception:
            pass
        AnyVisa.ReleaseSystem()

    def open(self):
        """Openes an abstract AnyVisa device for communication"""
        pass
    
    def close(self):
        """Closes communication channel of an abstract AnyVisa device"""
        pass
    
    def write_bytes(self, cmd : bytearray) -> int:
        """Writes given bytes to abstract AnyVisa device
           
            Parameters
               cmd        list of bytes to write

            Returns
                Number of bytes actually transferred
        """
        pass
        
    def read_bytes(self, cnt : int) -> bytearray:
        """Reads bytes from abstract AnyVisa device
        
            Parameters
                cnt     amount of bytes to read

            Returns
                Bytes array with binary data read back
        """
        pass
    
    def read(self) -> str:
        """Reads string from abstract AnyVisa device
        
            Returns
                Data read back from device as ASCII encoded string without trailing newline
        """
        pass
    
    def write(self, cmd : str):
        """Writes string to abstract AnyVisa device

            Parameters
                cmd     ASCII encoded string send to device without trailing newline
        """
        pass
    
    def query(self, cmd : str) -> str:
        """Sends ASCII string command to device and reads an ASCII string response afterwards
            This is a convenience function for write() followed by a read().

            Parameters
                cmd     ASCII encoded string send to device without trailing newline

            Returns
                Data read back from device as ASCII encoded string without trailing newline
        """
        pass
        
    def lib(self) -> str:
        """Returns the name of the backend actually used to interface the abstract AnyVisa device
        
            Returns
                name of the backend
        """
        return self.backend
    
    @classmethod
    def isQuery(cls, cmd : str):
        """Tests if given command is a SCPI query command

            This function tests if given command is a SCPI query command.
            A SCPI query command ends with a question mark. The function
            does not check if the command is valid or not.

            Parameters
                cmd     ASCII string request sent to device without trailing newline

            Returns
                True if command is a SCPI query command, False otherwise"""

         # Find the first space to isolate the first token
        first_space_index = cmd.find(" ")
        # If there's no space, the whole command is the first token
        first_token = cmd if first_space_index == -1 else cmd[:first_space_index]
        return first_token.endswith("?")
    
    @classmethod
    def isValidCommand(cls, command_str : str) -> tuple[bool, str]:
        """Tests if given command is a valid SCPI command

            This function tests if given command is a valid SCPI command.

            Parameters
                cmd     ASCII string request sent to device without trailing newline

            Returns
                Tuple with True if command is a valid SCPI command, False otherwise and an error description string
        """
        if not command_str or command_str.isspace():
            return False, "Empty command"
        # Split into command and parameters at first whitespace (if exists)
        parts = command_str.split(maxsplit=1)
        cmd_part = parts[0]
        param_part = parts[1] if len(parts) > 1 else ""
        
        # Special SCPI commands (* prefixed)
        if cmd_part.startswith('*'):
            cmd_upper = cmd_part.upper()
            if cmd_upper in {'*IDN?', '*RST', '*CLS', '*ESE', '*ESR?', 
                            '*OPC', '*OPC?', '*SRE', '*STB?', '*TST?', 
                            '*WAI', '*CAL?', '*DLF'}:
                return True, "Valid special command"
            return False, f"Invalid special command: {cmd_part}"
        # Validate command path structure, allowing for an optional leading colon
        if not re.fullmatch(
            r'^(:?[A-Za-z][A-Za-z0-9_]*(?::[A-Za-z][A-Za-z0-9_]*)*)\??$', 
            cmd_part,
            re.IGNORECASE
        ):
            return False, f"Invalid command path: {cmd_part}"
        # Query position validation
        if '?' in cmd_part and not cmd_part.endswith('?'):
            return False, "Query marker must be at command end"
        # Parameter validation (if parameters exist)
        if param_part:
            #replace all , within parantheses with a $ sign
            param_part = re.sub(r'\(([^()]*)\)', lambda m: m.group(0).replace(',', '$'), param_part)

            #Now split the parameters by commas, but not within parentheses
            # This regex splits by commas not inside parentheses
            params = param_part.split(',')

            for param in params:
                # Remove leading/trailing whitespace
                param = param.strip() 
                if not param:
                    return False, "Empty parameter found"
                
                #test if parameter is a valid signed or unsigned integer
                param_regex = r'^[+-]?\d+$'
                if re.fullmatch(param_regex, param):
                    continue

                #test if parameter is a valid SCPI hex parameter
                # SCPI hex parameters start with #H followed by hex digits
                param_regex = r'^[+-]?#H[0-9A-Fa-f]+$'
                if re.fullmatch(param_regex, param):
                    continue
            
                #test if parameter is a valid SCPI octal parameter
                # SCPI octal parameters start with #O followed by octal digits
                param_regex = r'^[+-]?#O[0-7]+$'
                if re.fullmatch(param_regex, param):
                    continue

                #test if parameter is a valid SCPI binary parameter
                # SCPI binary parameters start with #B followed by binary digits
                param_regex = r'^[+-]?#B[01]+$'
                if re.fullmatch(param_regex, param):
                    continue

                #test if parameter is a valid float with engneering notation
                param_regex = r'^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$'
                if re.fullmatch(param_regex, param):
                    continue
                
                #test if parameter is a valid string without quotes
                param_regex = r'^([a-zA-Z0-9_]+)$'
                if re.fullmatch(param_regex, param):
                    continue
                
                #test if parameter is a SCPI numeric list or channel list
                # This code is not 100% accurate, but it checks for common patterns. We never use it anyway!
                if(param.startswith('(') and param.endswith(')')):
                    # Remove the parentheses
                    param_content = param[1:-1].strip()

                    #Check if the string starts with an @ character, indicating a channel list
                    if param_content.startswith('@'):
                        # Remove the @ character
                        param_content = param_content[1:].strip()
                        
                        # Split by commas, but not within parentheses
                        numeric_list = param_content.split('$')

                        for item in numeric_list:
                            item = item.strip()
                            
                            # Check if the item is a valid channel (e.g., 1!2:3!4)
                            if re.fullmatch(r'^[+-]?(\d+!)*\d+(:[+-]?(\d+!)*\d+)?$', item):
                                continue

                            # Check if the item is a valid range (e.g., 1:5)
                            if re.fullmatch(r'^[+-]?(\d+!)*\d+(:[+-]?(\d+!)*\d+)?$', item):
                                continue

                            # Item is invalid
                            return False, f"Invalid channel list item: {item}"
                    else:
                        # Split by commas, but not within parentheses
                        numeric_list = param_content.split('$')
                        # Validate each item in the numeric list
                        for item in numeric_list:
                            item = item.strip()
                            
                            # Check if the item is a valid number (integer or float)
                            if re.fullmatch(r'^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$', item):
                                continue

                            # Check if the item is a valid range (e.g., 1:5)
                            if re.fullmatch(r'^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?\s*:\s*[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$', item):
                                continue

                            # check if the item is a valid range with step (e.g., 1:5:0.5)
                            if re.fullmatch(r'^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?\s*:\s*[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?\s*:\s*[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$', item):
                                continue

                            #item is invalid
                            return False, f"Invalid numeric list item: {item}"

                        continue

                #test if parameter is a valid string considing special characters and escape sequences
                param_regex = r'^[+-]?("[^"]*"|\'[^\']*\')$'
                if re.fullmatch(param_regex, param):
                    continue

                return False, f"Invalid parameter: {param}"
            
        return True, "Valid SCPI command"
    
    def auto_query(self, cmd : str) -> str:
        """Sends given ASCII string command to device and reads and ASCII string response if command is SCPI command query ending with an ?
            This is a convenience function for write() or query(). 

            Parameters
                cmd     ASCII string request sent to device without trailing newline

            Returns
                Data read back from device as ASCII encoded string without trailing newline
        """
        if self.isQuery(cmd):
            return self.query(cmd)
        self.write(cmd)
        return None

    def set_encryption(self,  password: str = None):
        """Enables/Disables device communication data encryption.

           Not implmented for generic devices and all communciation channels like USB, Ethernet...

            Parameters
               password        passwort string to enable. None to disable encryption.     
        """
        raise NotImplementedError("Setting encryption is not availiable for this communication backend. Only TL Visa supported!")
    
    def __str__(self):
        """ Represents the abstract AnyVisa device object as a string by returing the device resource string
        
            Returns
                device resource name string
        """
        return self.resourceStr
    
    def __repr__(self):  
        """ Represents the abstract AnyVisa device objects as a string for developers

            Returns
                class name with device resource name string
        """
        return f"AnyVisa Device({self.resourceStr})"
    
    def __eq__(self, other):
        """Tests if given objects equals this object
            The test compares the types and the resource strings

            Parameters
                other     test if given object match me

            Returns
                Result of test (True/False) if given object is also an AnyVisaDeviceWrapper object. NotImplemented for all other objects.
        """
        if isinstance(other, AnyVisaDeviceWrapper):
            return self.resourceStr == other.resourceStr
        return NotImplemented
    
    def __ne__(self, other):
        """Tests if given objects not equals this object
            The test compares the types and the resource strings

            Parameters
                other     test if given object does not match me

            Returns
                Result of test (True/False) if given object is also an AnyVisaDeviceWrapper object. NotImplemented for all other objects.
        """
        x = self.__eq__(other)
        if x is NotImplemented:
            return NotImplemented
        return not x
    
    def __lt__(self, other):
        """Tests object to be less than given object
            Implements the functionality of the less than operator “<”,
            it returns a boolean value according to the condition i.e. 
            it returns true if a<b where a and b are the objects of the class.

            Parameters
                other     It is a object that will be compared further with the other object.

            Returns
                Returns True or False depending on the comparison.
        """
        if isinstance(other, AnyVisaDeviceWrapper):
            return self.resourceStr < other.resourceStr
        elif isinstance(other, str):
            return self.resourceStr < other
        else:
            return NotImplemented

    def __hash__(self):
        """Returns an hash for given abstract AnyVisa device
        
            Returns
                Hash based on device resource string
        """
        return self.resourceStr.__hash__()

class TLVisaWrapper (AnyVisaDeviceWrapper):
    """TL Visa device class

    This class is a wrapper for a Thorlabs Visa device. It uses
    a base class to provide a common interface with National
    Instrument Visa devices. 
    """

    rm = None

    def __init__(self, device):
        """Constructs a new TL visa device

        This function does not establish the connection. Call open() within with block
        before starting communication.

         Parameters:
            device (TL_VisaDevice): TL_Visa device object
         """
        AnyVisaDeviceWrapper.__init__(self, device.__str__(), "TL_Visa")
        self.device = device
    
    @classmethod
    def SetSearchNetwork(cls, searchNetIpv4 : str):
        """Sets the network for the ethernet device search

            If you have multiple ethernet networks on you windows PC
            the broadcast is sent to the network with the lowest 
            NICE level. To search in other networks define the network
            IPv4 broadcast adress. For example 192.168.172.255.

            Parameters
                searchNetIpv4     IPv4 search network brodcast address
        """
        if cls.rm is None:
            cls.rm = TL_Visa.ResourceManager()
        cls.rm.setAttribute(0x3FFF0403, searchNetIpv4)

    @classmethod
    def FindResources(cls, findPattern : str) -> List[AnyVisaDeviceWrapper]:
        """Searches for all devices using Thorlabs driver

            This method starts a device search. The selection might be filted by given NI Visa style filter 
            string. The function will find Thorlabs Ethernet devices, Thorlabs USB/TMC devices and 
            serial ports.
        
            Parameters
                findPattern     Visa like device search pattern to filter device list. Not device resource string!

            Returns
                List of found device objects matching given filter condition
        """
        if cls.rm is None:
            cls.rm = TL_Visa.ResourceManager()
            
        devList = cls.rm.list_resources(findPattern)
        res = []
        for dev in devList:
            res.append(TLVisaWrapper(dev))
        return res
    
    @classmethod
    def InitResource(cls, resourceStr : str) -> AnyVisaDeviceWrapper:
        """Creates a TL Visa wrapper object for device by resource string
           
            Call this method as an alternative for FindResources() to init
            a device object for a known resource string. Once initialized use
            the returned object and call open or use python with block. 


            Parameters
                findPattern     Visa like device research string. Not find resource string!

            Returns
                Device object for given resource string
        """
        if cls.rm is None:
            cls.rm = TL_Visa.ResourceManager()
        return TLVisaWrapper(cls.rm.createInstance(resourceStr))
    
    @classmethod
    def ReleaseSystem(cls):
        """Closes the TLvisa library finally

            Call this function finally if TLvisa library is not longer used for any device communication.
            Best practice is to use a python with block to ensure this function is called in any case.
        """
        if cls.rm is not None:
            cls.rm.close()
        cls.rm = None

    def open(self):
        """Openes the communication channel to a Thorlabs device
        
            Normally this function is called within start of python with block
        """
        self.device.open()
        
        #Enables thorlabs framing protocol
        if 'TCPIP' in self.resourceStr:
            self.device.setAttribute(0x3FFF0400, 1)

    def set_encryption(self, password: str = None):
        """Enables/Disables device communication data encryption.

           This funciton needs to be set directly after open() to set
           the used passwort for the communication encryption. It needs
           to be called before the first communication takes place. If 
           the resource string contains substring CRY encrpytion is
           enabled on this device and calling this function is mandatory.
           If the device is openend manually its up to the user to
           know if the device is encrypted or not. There will be no
           error message if communicating with an enrypted device without
           encrpytion but device communication will fail.

            Parameters
               password        passwort string to enable. None to disable encryption.           
        """
        if password is not None:
            self.device.setAttribute(0x3FFF0401, str(password))
        else:
            self.device.setAttribute(0x3FFF0401, 0)
            
    def close(self):
        """Closes the communication channel to a Thorlabs device

            Normally this function is called automatically when python with block is used.
            No not use this object anymore after close has been used.
        """
        self.device.close()
    
    def write_bytes(self, cmd : bytearray) -> int:
        """Writes given bytes to Thorlabs device
            
            Writes binary data via USB, Ethernet or serial wire to a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
               cmd        list of bytes to write

            Returns
                Number of bytes actually transferred
        """
        try:
            return self.device.write_bytes(cmd)
        except TL_VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except TL_VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
        
    def read_bytes(self, cnt : int) -> bytearray:
        """Reads given amount of bytes from Thorlabs device
            
            Reads data via USB, Ethernet or serial wire from a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
                cnt     amount of bytes to read

            Returns
                Bytes array with binary data read back
        """
        try:
            return self.device.read_bytes(cnt)
        except TL_VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except TL_VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
            
    def read(self) -> str:
        """Reads string from Thorlabs device
            
            Reads string data via USB, Ethernet or serial wire from a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Returns
                String with data read back
        """
        try:
            return self.device.read().strip()
        except TL_VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except TL_VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
    
    def write(self, cmd : str):
        """Writes string to Thorlabs device
            
            Writes string data via USB, Ethernet or serial wire to a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
                cmd     ASCII string request sent to device without trailing newline
        """
        try:
            return self.device.write(cmd)
        except TL_VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except TL_VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
    
    def query(self, cmd : str) -> str:
        """Sends ASCII string command to device and reads an ASCII string response afterwards
            This is a convenience function for write() followed by a read().

            Parameters
                cmd     ASCII string request sent to device without trailing newline

            Returns
                Response string from device as ASCII encoded string without trailing newline
        """
        try:
            return self.device.query(cmd)
        except TL_VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except TL_VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
    
class NiVisaWrapper (AnyVisaDeviceWrapper):
    """NI Visa device class

    This class is a wrapper for a National Instrument Visa device. It uses
    a base class to provide a common interface with Thorlabs
    Instrument Visa devices. The NI Visa library allows communication with
    Serial, Ethernet devices and USB TMC devices. For USB TMC it is mandatory
    that the device uses the USB/TMC driver by National Instrument an not
    the Thorlabs driver! This wrapper class is based on pyvisa package.
    """

    rm = None
    
    def __init__(self, resStr : str):
        """Constructs a new NI Visa device

        This function does not establish the connection. Call open() within with block
        before starting communication.

         Parameters:
            resStr (str): device resource string
         """
        AnyVisaDeviceWrapper.__init__(self, resStr, "NI_Visa")
        if NiVisaWrapper.rm is None:
            NiVisaWrapper.rm = pyvisa.ResourceManager()
        self.device = None
    
    @classmethod
    def FindResources(cls, findPattern : str) -> List[AnyVisaDeviceWrapper]:
        """Searches for all devices using NI Visa driver

            This method starts a device search. The selection might be filted by given NI Visa style filter 
            string. The function will Ethernet devices, NI USB/TMC devices and 
            serial ports. For USB TMC it is mandatory that the device uses 
            the USB/TMC driver by National Instrument an not the Thorlabs driver!
        
            Parameters
                findPattern     Visa like device search pattern to filter device list. 

            Returns
                List of found device resource strings matching given filter condition
        """
        if cls.rm is None:
            cls.rm = pyvisa.ResourceManager()
            
        devList = cls.rm.list_resources(findPattern)
        res = []
        for dev in devList:
            res.append(NiVisaWrapper(dev))
        return res

    @classmethod
    def InitResource(cls, resourceStr : str) -> AnyVisaDeviceWrapper:
        """Creates a NI  Visa wrapper object for device by resource string
           
            Call this method as an alternative for FindResources() to init
            a device object for a known resource string. Once initialized use
            the returned object and call open or use python with block. 


            Parameters
                findPattern     Visa like device research string. Not find resource string!

            Returns
                Device object for given resource string
        """
        return NiVisaWrapper(resourceStr)   

    @classmethod
    def ReleaseSystem(cls):
        """Closes the NI Visa library finally

            Call this function finally if NI Visa library is not longer used for any device communication.
            Best practice is to use a python with block to ensure this function is called in any case.
        """
        if cls.rm is not None:
            try:                
                cls.rm.close()
                cls.rm = None
            except Exception:
                pass
            
    def open(self):
        """Openes the communication channel to a NI Visa device
        
            Normally this function is called within start of python with block
        """
        if NiVisaWrapper.rm is None:
            NiVisaWrapper.rm = pyvisa.ResourceManager()
        self.device = NiVisaWrapper.rm.open_resource(self.resourceStr)
        
    def close(self):
        """Closes the communication channel to a NI Visa device

            Normally this function is called automatically when python with block is used.
            No not use this object anymore after close has been used. 
        """
        if self.device is not None:
            # Send remote local lockout
            self.device.control_ren(0)
            self.device.close()
            self.device = None
            
    def write_bytes(self, cmd : bytearray) -> int:
        """Writes given bytes to NI Visa device
            
            Writes binary data via USB, Ethernet or serial wire to a device using pyvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
               cmd        list of bytes to write

            Returns
                Number of bytes actually transferred
        """
        try:
            return self.device.write_bytes(cmd)
        except pyvisa.VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except pyvisa.errors.VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
        except pyvisa.Error as e:
            raise AnyVisaException(e) from None
        
    def read_bytes(self, cnt : int) -> bytearray:
        """Reads given amount of bytes from NI Visa device
            
            Reads data via USB, Ethernet or serial wire from a device using pyvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
                cnt     amount of bytes to read

            Returns
                Bytes array with binary data read back
        """
        try:
            return self.device.read_bytes(cnt)
        except pyvisa.VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except pyvisa.errors.VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
        except pyvisa.Error as e:
            raise AnyVisaException(e) from None
    
    def read(self) -> str:
        """Reads string from NI Visa device
            
            Reads string data via USB, Ethernet or serial wire from a device using pyvisa.
            Requires an established communication channel by open(). Do not use after close().

            Returns
                Bytes array with binary data read back
        """
        try:
            return self.device.read()
        except pyvisa.VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except pyvisa.errors.VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
        except pyvisa.Error as e:
            raise AnyVisaException(e) from None
    
    def write(self, cmd : str):
        """Writes string to NI Visa device
            
            Writes string data via USB, Ethernet or serial wire to a device using pyvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
                cmd     ASCII encoded string send to device without trailing newline
        """
        try:
            return self.device.write(cmd)
        except pyvisa.VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except pyvisa.errors.VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
        except pyvisa.Error as e:
            raise AnyVisaException(e) from None
    
    def query(self, cmd : str) -> str:
        """Sends ASCII string command to device and reads an ASCII string response afterwards
            This is a convenience function for write() followed by a read().

            Parameters
                cmd     ASCII encoded string send to device without trailing newline

            Returns
                Data read back from device as ASCII encoded string without trailing newline
        """
        try:
            return self.device.query(cmd)
        except pyvisa.VisaIOError as e:
            raise AnyVisaIOError(e.error_code, e.description) from None
        except pyvisa.errors.VisaIOWarning as w:
            raise AnyVisaIOWarning(w.error_code, w.description) from None
        except pyvisa.Error as e:
            raise AnyVisaException(e) from None

class AnyVisa:
    @classmethod
    def TL_Open(cls, rsrStr : str) -> AnyVisaDeviceWrapper:
        """ Opens a device by resource string using TL Visa
            
            Use this method to open a single known device by resource string.
            The device needs to use the TL_Visa driver and not Ni_Visa. 
            Otherwise open will fail. It is easier to use FindResources()
            and to open one of the listed devices. 

        Parameters
            rsrStr     device resource Visa string for device with TL Visa driver

        Returns
            device object if device is found. None in case device is not present.
        """
        return TLVisaWrapper.InitResource(rsrStr)
    
    @classmethod
    def Ni_Open(cls, rsrStr : str) -> AnyVisaDeviceWrapper:
        """ Opens a device by resource string using National Instruments Visa

            Use this method to open a single known device by resource string.
            The device needs to use the National Instruments Visa  driver and not TL_Visa. 
            Otherwise open will fail. It is easier to use FindResources()
            and to open one of the listed devices.

        Parameters
            rsrStr     device resource visa string for device with NI Visa driver

        Returns
            device object if device is found. None in case device is not present.
        """
        return NiVisaWrapper.InitResource(rsrStr)

    @classmethod
    def SetSearchNetwork(cls, searchNetIpv4:str):
        """Sets the network for the ethernet device search

            If you have multiple ethernet networks on you windows PC
            the broadcast is sent to the network with the lowest 
            NICE level. To search in other networks define the network
            IPv4 broadcast adress. For example 192.168.172.255.

            Parameters
                searchNetIpv4     IPv4 search network brodcast address
        """
        TLVisaWrapper.SetSearchNetwork(searchNetIpv4)

    @classmethod
    def FindResources(cls, findPattern : str = '?*::INSTR') -> List[AnyVisaDeviceWrapper]:
        """ Searches for devices matching given find pattern
            
            Use this command to get a list of all USB/TMC, serial Ports and 
            ethernet devices. The function uses Thorlabs and NI driver
            if present on the system. For NI support ensure NI Visa and
            python pyvisa module has been installed previously.

        Parameters
            findPattern     Visa like device search pattern to filter device list. 

        Returns
            List of found devices (objects) matching given filter condition
        """
        devices = []
        if isNiVisa:
            devices.extend(NiVisaWrapper.FindResources(findPattern))
        if isTLVisa:
            devices.extend(TLVisaWrapper.FindResources(findPattern))
        
        return list(set(devices))

    @classmethod
    def ReleaseSystem(cls):
        """ Closes the library finally

            Call this function finally if the library is not longer used for any device communication.
        """
        if isNiVisa:
            NiVisaWrapper.ReleaseSystem()
        if isTLVisa:
            TLVisaWrapper.ReleaseSystem()

    @classmethod
    def GetBackendNames(cls) -> List[str]:
        """ Returns a list of supported backend names

        Returns
            List with strings of supported backends on this machine
        """
        res = []
        if isNiVisa:
            res.append("NI_Visa")
        if isTLVisa:
            res.append("TL_Visa")
        return res

"""
# Start a device search and open first device found
devices = []
devices = AnyVisa.FindResources("?*")
if devices:
    with devices[0] as d:
        print(d)
        print(d.lib())
        print(d.auto_query("*IDN?"))
"""

"""
# Open a known device by resource string
with AnyVisa.TL_Open("TCPIP0::192.168.10.64::mun1234_T00000003::INSTR") as d:
    print(d)
    print(d.lib())
    print(d.auto_query("*IDN?"))

"""

"""
    device = None
    try:
        devices = []
        devices = AnyVisa.FindResources("?*:INSTR")
        print(devices)
        if devices:
            device = devices[0]
            device.open()
            print(device)
            print(device.lib())
            print(device.auto_query("*IDN?"))

    finally:
        if device is not None:
            try:
                device.close()
            except Exception:
                pass
        AnyVisa.ReleaseSystem()
"""