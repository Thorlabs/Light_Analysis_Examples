# -*- coding: utf-8 -*-
"""
   Anyvisa is wrapper for TL Visa and NI Visa device communication via SCPI commands

   This wrapper class access the TL Visa shared library via pyhton c types. This is an
   internal module used by Anyvisa. 

   Thorlabs GmbH - Proprietary License! Read License.txt
"""
__copyright__ = "copyright(c) 2022-2023, Thorlabs GmbH"
__date__ = "30-Apr-2023"
__license__ = "Proprietary"
__version__ = "0.2.0"

import ctypes
import os
from typing import List

#TL_Visa:                   TL Visa shared library loader and utility class
#TL_VisaResourceManager:    Resource manager to create and load instances of TL_VisaDevice
#TL_VisaDevice:             TL Visa device connetion class. DO NOT INSTANCIATE DIRECTLY. Use TL_VisaResourceManager!

class TL_VisaIOError(Exception):
    """ TL Visa shared library IO error exception class """
    def __init__(self, error_code, message):
        self.error_code = error_code
        self.description = str(error_code) + ' (' + hex(error_code & (2**32-1)) + ') - ' + message
        super().__init__(self.description)
        
class TL_VisaIOWarning(Exception):
    """ TL Visa shared library IO Warning exception class """
    def __init__(self, error_code, message):
        self.error_code = error_code
        self.description = str(error_code) + ' (' + hex(error_code & (2**32-1)) + ') - ' + message
        super().__init__(self.description)
        
        
class TL_VisaDevice(object):
    """ TL Visa device class for communication

        TL Visa Device class represeents a single TL Visa device communication
        channel. Do not instanciate              
    """

    def __init__(self, res: str, resHand : ctypes.c_uint32):
        """ Constructs a new TL visa device communication class

            Parameters
                res(str):               Device Visa like resource name
                resHand (c_uint32):     Resource handle for device communication
        """
        self.resName = res
        self.resHandle = resHand
        self.devHandle = ctypes.c_uint32(0)
        
    def close(self):        
        """ Closes the TL Visa communication channel to device 

            Ensure to also close the library finally not only the communication channel.
        """
        TL_Visa.Close(self.resHandle) 
        TL_Visa.Close(self.devHandle)
        self.resHandle.value = 0   
        self.devHandle.value = 0
 
    def open(self, timeout_ms = 1000):
        """  Openes a TL Visa communication channel via USB/TMC, Serial or Ethernet interface.

            Paramerters
                timeout_ms(int):               device communication timeout in ms for read operations
        """
        #DLL function import
        #ViStatus _VI_FUNC TL_viOpen (ViSession sesn, ViRsrc name, ViAccessMode mode, ViUInt32 timeout, ViPSession vi);
        TL_viOpen = TL_Visa.tlVisa.TL_viOpen
        TL_viOpen.argtypes = [ctypes.c_uint32, ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
        TL_viOpen.restype = ctypes.c_int32
                    		
        if self.devHandle.value == 0: 
            TL_viOpenDefaultRM = TL_Visa.tlVisa.TL_viOpenDefaultRM
            TL_viOpenDefaultRM.argtypes = [ctypes.POINTER(ctypes.c_uint32)]
            TL_viOpenDefaultRM.restype = ctypes.c_int32 
            #Prepare ctypes parameters
            self.resHandle = ctypes.c_uint32(0) 
                #Call DLL function
            result = TL_Visa.tlVisa.TL_viOpenDefaultRM(ctypes.byref(self.resHandle)) 
        
        #Prepare ctypes parameters
        byteDeviceResStr = self.resName.encode('ascii')
        mode = ctypes.c_uint32(0)
        timeout = ctypes.c_uint32(timeout_ms)
        
        #Call DLL function
        result = TL_Visa.tlVisa.TL_viOpen(self.resHandle, byteDeviceResStr, mode, timeout, ctypes.byref(self.devHandle)) 
        if result:
            TL_Visa.RaiseError(self.resHandle, result)
            
    def setAttribute(self, attr: int, val):
        """Sets a specified device attribute

            Call this function to change a device attribute. The function
            supports int and string attributes.

            Paramerters
                attr(int):               Device attribute to change
                value(int, str):         string or int value for attribute
        """
        if type(val) == str:
            res = TL_Visa.SetStrAttribute(self.devHandle, attr, val)
        else:
            res = TL_Visa.SetAttribute(self.devHandle, attr, val)
        if res:
            TL_Visa.RaiseError(self.resHandle, res)

    def getAttribute(self, attr, type=int):
        """ Returns device attribute

            Call this function to query the value of the given device attribute.
            The type of attribute has to be specified. Int and string are supported

            Paramerters
                attr(int):               Device attribute to query
                type(int, str)           type of attribute value to query

            Returns
                value of attribute. Type depends on given parameter

        """
        if type == int:
            res, val = TL_Visa.GetAttribute(self.devHandle, attr)
        else:
            res, val = TL_Visa.GetStrAttribute(self.devHandle, attr)
        if res:
            TL_Visa.RaiseError(self.resHandle, res)
        return val

    def write_bytes(self, data: bytearray) -> int:
        """ Writes given bytes via TL Visa shared library
            
            Writes binary data via USB, Ethernet or serial wire to a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
               data        byte array with data to write

            Returns
                Number of bytes actually transferred
        """
        #DLL function import
        #ViStatus _VI_FUNC TL_viWrite (ViSession vi, ViBuf  buf, ViUInt32 cnt, ViPUInt32 retCnt);
        TL_viWrite = TL_Visa.tlVisa.TL_viWrite
        TL_viWrite.argtypes = [ctypes.c_uint32, ctypes.c_char_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
        TL_viWrite.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        binDataLen = ctypes.c_uint32(len(data))
        writtenLen = ctypes.c_uint32(0)
                
        #Call DLL function
        result = TL_Visa.tlVisa.TL_viWrite(self.devHandle, data, binDataLen, ctypes.byref(writtenLen))
        if result:
            TL_Visa.RaiseError(self.resHandle, result)
        return writtenLen.value
    
    def read_bytes(self, cnt : int) -> bytearray:  
        """ Reads given amount of bytes via TL Visa shared library
            
            Reads data via USB, Ethernet or serial wire from a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
                cnt     amount of bytes to read

            Returns
                Byte array with binary data read back
        """ 
        #DLL function import 
        #ViStatus _VI_FUNC TL_viRead (ViSession vi, ViPBuf buf, ViUInt32 cnt, ViPUInt32 retCnt);
        TL_viRead = TL_Visa.tlVisa.TL_viRead
        TL_viRead.argtypes = [ctypes.c_uint32, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
        TL_viRead.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        buf = (ctypes.c_ubyte * cnt)()
        binDataLen = ctypes.c_uint32(cnt)
        readLen = ctypes.c_uint32(0)
        
        #Call DLL function
        result = TL_Visa.tlVisa.TL_viRead(self.devHandle, buf, binDataLen, ctypes.byref(readLen))
        if result:
            TL_Visa.RaiseError(self.resHandle, result)
        
        return bytearray(buf[0:readLen.value])

    def write(self, cmd: str) -> int:
        """ Writes string to device via TL Visa shared library
            
            Writes string data via USB, Ethernet or serial wire to a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Parameters
                cmd     ASCII encoded string send to device without trailing newline
        """
        cmd = cmd + '\n'
        return self.write_bytes(cmd.encode('ascii'))

    def read(self) -> str:
        """ Reads string via TL Visa shared library
            
            Reads string data via USB, Ethernet or serial wire from a device using TLvisa.
            Requires an established communication channel by open(). Do not use after close().

            Returns
                String with data read back
        """
        byteArr = self.read_bytes(4096)
        return byteArr.decode('ascii').strip()

    def query(self, request: str) -> str:
        """ Sends string command to device and reads an ASCII string response afterwards via TL Visa shared library
            This is a convenience function for write() followed by a read().

            Parameters
                request     ASCII string request sent to device without trailing newline

            Returns
                Response string from device as ASCII encoded string without trailing newline
        """
        self.write(request)
        return self.read()

    def auto_query(self, cmd: str) -> str:
        """ Sends given ASCII string command to device and reads and string response if command is SCPI command query ending with an ?
            This is a convenience function for write() or query(). 

            Parameters
                cmd     ASCII string request sent to device without trailing newline

            Returns
                Data read back from device as ASCII encoded string without trailing newline
        """
        self.write(cmd)
        if cmd.endswith('?'):
            return self.read()    
    
    def __str__(self):
        """ Represents the abstract AnyVisa device object as a string by returing the device resource string

            Returns
                device resource name string
        """
        return self.resName
    
    def __repr__(self):  
        """ Represents the abstract AnyVisa device objects as a string for developers

            Returns
                class name with device resource name string
        """

        return f"TLVisa Device({self.resName})"
    
class TL_VisaResourceManager(object):
    """ TL Visa device resource manager class
        
        This class is designed to be a singleton. Do not instanciate own members. Use
        TL_Visa ResourceManager() to get the singleton instance. The resource manager 
        allows searching for TL Visa devices.
    """
    def __init__(self):
        #DLL function import
        #ViStatus _VI_FUNC  TL_viOpenDefaultRM (ViPSession vi);
                
        TL_viOpenDefaultRM = TL_Visa.tlVisa.TL_viOpenDefaultRM
        TL_viOpenDefaultRM.argtypes = [ctypes.POINTER(ctypes.c_uint32)]
        TL_viOpenDefaultRM.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        self.handle = ctypes.c_uint32(0)
        
        #Call DLL function
        result = TL_Visa.tlVisa.TL_viOpenDefaultRM(ctypes.byref(self.handle))
        if result:
            raise ValueError(str(result))  
                    
    def list_resources(self, searchPattern : str ='?*::INSTR') -> List[TL_VisaDevice]:
        """ Searches for TL Visa devices matching given find pattern
            
            Use this command to get a list of all USB/TMC, serial ports and 
            ethernet devices. The function uses TL Visa.

            Parameters
                findPattern     Visa like device search pattern to filter device list. 

            Returns
                A TL_Visa device object list with search results
        """
        devs = []
    
        #DLL function import
        #ViStatus _VI_FUNC TL_viFindRsrc (ViSession sesn, ViString expr, ViPFindList vi, ViPUInt32 retCnt, ViChar _VI_FAR desc[]);
        TL_viFindRsrc = TL_Visa.tlVisa.TL_viFindRsrc
        TL_viFindRsrc.argtypes = [ctypes.c_uint32, ctypes.c_char_p, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32), ctypes.c_char_p]
        TL_viFindRsrc.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        findListHandle = ctypes.c_uint32(0)
        findListLenCnt = ctypes.c_uint32(0)
        byteSearchPatternStr = searchPattern.encode('ascii')
        resourceName = (ctypes.c_char * 512)()
        
        #Call DLL function
        result = TL_Visa.tlVisa.TL_viFindRsrc(self.handle, ctypes.c_char_p(byteSearchPatternStr), ctypes.byref(findListHandle), ctypes.byref(findListLenCnt), resourceName)
        if result:
            if result == -1073807343: #(0xbfff0011) - Insufficient location information or the device or resource is not present in the system.
                return []
            TL_Visa.RaiseError(self.handle, result)
       
        devs.append(self.createInstance(resourceName.value.decode("ascii")))
        
        #DLL function import
        #ViStatus _VI_FUNC TL_viFindNext (ViFindList vi, ViChar _VI_FAR desc[]);
        TL_viFindNext = TL_Visa.tlVisa.TL_viFindNext
        TL_viFindNext.argtypes = [ctypes.c_uint32, ctypes.c_char_p]
        TL_viFindNext.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        
        #iterate find list
        for x in range(1, findListLenCnt.value):
            #Call DLL function
            result = TL_Visa.tlVisa.TL_viFindNext(findListHandle, resourceName)
            if result:
                TL_Visa.RaiseError(self.handle, result)
            devs.append(self.createInstance(resourceName.value.decode("ascii")))
        
        #close find list
        TL_Visa.Close(findListHandle)
        
        #reopen resource manager again. Has been closed by previous close automatically as no other resources where left! (Autoclose)
        result = TL_Visa.tlVisa.TL_viOpenDefaultRM(ctypes.byref(self.handle))
        if result:
            raise ValueError(str(result))   
        return devs

    def createInstance(self, resourceName: str) -> TL_VisaDevice:
        """Creates a new instance of a TLVisa device class

            Parameters
                findPattern     device resource string

            Returns
                A TL_Visa device class
        """
        return TL_VisaDevice(resourceName, self.handle)

    def setAttribute(self, attr: int, val):
        """Sets a specified resource manager attribute

            Call this function to change a resource manager attribute. The function
            supports int and string attributes.

            Paramerters
                attr(int):               Device attribute to change
                value(int, str):         string or int value for attribute
        """
        res = 0
        if type(val) == str:
            res = TL_Visa.SetStrAttribute(self.handle, attr, val)
        else:
            res = TL_Visa.SetAttribute(self.handle, attr, val)
        if res:
            TL_Visa.RaiseError(self.handle, res)

    def getAttribute(self, attr, type=int):
        """ Returns resource manager attribute

            Call this function to query the value of the given resource manager attribute.
            The type of attribute has to be specified. Int and string are supported

            Paramerters
                attr(int):               Device attribute to query
                type(int, str)           type of attribute value to query

            Returns
                value of attribute. Type depends on given parameter

        """
        if type == int:
            res, val = TL_Visa.GetAttribute(self.handle, attr)
        else:
            res, val = TL_Visa.GetStrAttribute(self.handle, attr)
        if res:
            TL_Visa.RaiseError(self.handle, res)
        return val
        

    def close(self):
        """ Closes the resource manager and releases the TL Visa dll

            Call once if device communication is complete to release the Resource Manager
            and the TL Visa library gracefully. Do not use any device object or resource 
            manager after calling this method.
        """
        TL_Visa.Close(self.handle)
        self.handle.value = 0
        
        if TL_Visa.tlVisa:
            del(TL_Visa.tlVisa)
        
        TL_Visa.tlVisa = None
        TL_Visa.resManager = None
    

class TL_Visa:
    """ TL Visa shared library loader class 

        The class is responsible to load the TL visa shared library for the system.
        Once the DLL is loaded the TL_VisaDevice and TL_VisaResourceManager class
        can work with the dll.
    """
    resManager = None
    tlVisa = None
    
    @classmethod
    def ResourceManager(cls) -> TL_VisaResourceManager:
        """ Loads shared library and returns the TL Visa resource manager singleton instance

            This method loads the shared library for the local system and returns the 
            TL_VisaResourceManager singleton instance to start device search. Always
            ensure to release the TL Visa resources finally by calling Close().
        """
        #test if we load DLL already
        if TL_Visa.tlVisa is None:
            
            #handle DLL open for windows
            if os.name == 'nt':
                folder = os.path.dirname(os.path.abspath(__file__))
                dll_path = ""
                #test if 64bit python
                if ctypes.sizeof(ctypes.c_voidp) == 8:
                    dll_path = os.path.join(folder, 'bin\win\TLVisa_64.dll')
                else:
                    dll_path = os.path.join(folder, 'bin\win\TLVisa_32.dll')
                
                TL_Visa.tlVisa = ctypes.CDLL(dll_path)
        
        #init resource manager class only once during runtime and ensure
        if TL_Visa.resManager is None:
            TL_Visa.resManager = TL_VisaResourceManager()
        
        TL_Visa.resManager = TL_Visa.resManager
        TL_Visa.tlVisa = TL_Visa.tlVisa
        return TL_Visa.resManager
    
    @classmethod
    def RaiseError(cls, resManHandle, errCode: int):
        """ Raises an TL Visa IO error or warning exception for an TL Visa error code

            Parameters
                resManHandle(c_uint32)  device resource manager handle
                errCode(int)            error code to translate to exception
        """
        
        #DLL function import
        #ViStatus _VI_FUNC  TL_viStatusDesc    (ViObject vi, ViStatus status, ViChar _VI_FAR desc[]);
        TL_viStatusDesc = TL_Visa.tlVisa.TL_viStatusDesc
        TL_viStatusDesc.argtypes = [ctypes.c_uint32, ctypes.c_int32, ctypes.c_char_p]
        TL_viStatusDesc.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        code = ctypes.c_int32(errCode)
        descrip = (ctypes.c_char * 1024)()

        descr = "No details"
        
        try:
            #Call DLL function
            cls.tlVisa.TL_viStatusDesc(resManHandle, code, descrip)
            descr = descrip.value.decode("ascii")       
        except Exception:
            pass
        
        if errCode < 0:
            raise TL_VisaIOError(errCode, descr)
        else:
            raise TL_VisaIOWarning(errCode, descr)            
    

    @classmethod
    def SetAttribute(cls, handle, attr: int, value:int):
        """  Sets a specified attribute for the object

            Paramerters
                handle(int):             handle the attribute should be changed for. Device or resource ranager
                attr(int):               Specifies the attribute whose value you want to set.
                value(int):              The value to which to set the specified attribute.
        """
        #DLL function import
        #ViStatus _VI_FUNC  TL_viSetAttribute  (ViObject vi, ViAttr attrName, ViAttrState attrValue);
        TL_viSetAttr = TL_Visa.tlVisa.TL_viSetAttribute
        
        if ctypes.sizeof(ctypes.c_voidp) == 8:
            TL_viSetAttr.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint64]
        else:
            TL_viSetAttr.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
        TL_viSetAttr.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        at = ctypes.c_uint32(attr)
        if ctypes.sizeof(ctypes.c_voidp) == 8:
            val = ctypes.c_uint64(value)
        else:
            val = ctypes.c_uint32(value)

        #Call DLL function
        res = TL_Visa.tlVisa.TL_viSetAttribute(handle, at, val)
        return res
    
    @classmethod
    def SetStrAttribute(cls, handle, attr: int, valueStr:str):
        """  Sets a specified attribute for the object

            Paramerters
                handle(int):             handle the attribute should be changed for. Device or resource ranager
                attr(int):               Specifies the attribute whose value you want to set.
                value(str):              value string for attribute
        """
        #DLL function import
        #ViStatus _VI_FUNC  TL_viSetAttribute  (ViObject vi, ViAttr attrName, ViAttrState attrValue);
        TL_viSetAttr = TL_Visa.tlVisa.TL_viSetAttribute
        
        TL_viSetAttr.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
        TL_viSetAttr.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        at = ctypes.c_uint32(attr)
        byteValueStr = valueStr.encode('ascii')
        val = ctypes.cast(byteValueStr, ctypes.c_void_p)

        #Call DLL function
        res = TL_Visa.tlVisa.TL_viSetAttribute(handle, at, val)
        return res
    
    
    @classmethod
    def GetAttribute(cls, handle, attr: int) -> int:
        """  Gets int value for specified attribute

            Paramerters
                handle(int):             handle the attribute should be changed for. Device or resource ranager
                attr(int):               attribute to query
        """
        #DLL function import
        #ViStatus _VI_FUNC  TL_viGetAttribute  (ViObject vi, ViAttr attrName, void _VI_PTR attrValue)
        TL_viGetAttr = TL_Visa.tlVisa.TL_viGetAttribute
        TL_viGetAttr.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
        TL_viGetAttr.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        at = ctypes.c_uint32(attr)
        if ctypes.sizeof(ctypes.c_voidp) == 8:
            val  = ctypes.c_uint64(0)
        else:
            val  = ctypes.c_uint32(0)
        #Call DLL function
        res = TL_Visa.tlVisa.TL_viGetAttribute(handle, at, ctypes.byref(val))
        return res, val.value
    
    @classmethod
    def GetStrAttribute(cls, handle, attr: int) -> str:
        """  Gets string value for specified attribute

            Paramerters
                handle(int):             handle the attribute should be changed for. Device or resource ranager
                attr(int):               attribute to query
        """
        #DLL function import
        #ViStatus _VI_FUNC  TL_viGetAttribute  (ViObject vi, ViAttr attrName, void _VI_PTR attrValue)
        TL_viGetAttr = TL_Visa.tlVisa.TL_viGetAttribute
        TL_viGetAttr.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
        TL_viGetAttr.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
        at = ctypes.c_uint32(attr)
        attrStrVal = (ctypes.c_char * 512)()

        #Call DLL function
        res = TL_Visa.tlVisa.TL_viGetAttribute(handle, at, attrStrVal)
        return res, attrStrVal.value.decode("ascii")

    @classmethod
    def Close(cls, handle):
        """ Releases the TL Visa library and its resources finally.
            
            Call once if device communication is complete to release the TL Visa library
            and its resources gracefully. Do not use any device object or resource 
            manager after calling this method.

            Parameters
                resManHandle(c_uint32)  device resource manager handle
        """
        #do nothing for empty handle
        if handle.value == 0 or TL_Visa.tlVisa is None:
            return
                
        #DLL function import
        #ViStatus _VI_FUNC  TL_viclose         (ViObject vi);
        TL_viClose = cls.tlVisa.TL_viClose
        TL_viClose.argtypes = [ctypes.c_uint32]
        TL_viClose.restype = ctypes.c_int32
        
        #Prepare ctypes parameters
    
        #Call DLL function
        try:
            TL_viClose(handle)
        except Exception:
            pass


"""
dev = None
rm = None
try:
    rm = TL_Visa.ResourceManager()
    
    devs =  rm.list_resources("?*")
    print(devs)
    
    if len(devs) > 0 :
        dev = devs[0]
        dev.open(1000)
    
        print(dev.query("*IDN?"))
        
finally:
    if dev is not None:
        dev.close()
    if rm is not None:
        rm.close()
"""